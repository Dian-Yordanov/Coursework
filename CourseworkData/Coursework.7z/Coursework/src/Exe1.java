/**
 * Created with IntelliJ IDEA.
 * User: Nocturnal Cyan
 * Date: 29/01/13
 * Time: 12:04
 * To change this template use File | Settings | File Templates.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class Exe1 extends JFrame implements ActionListener {

              /**
               * @param args
               */
              JTextField jtfNumber1;
              JTextField jtfNumber2;


              public static void main(String[] args) {
              JFrame myFrame = new JFrame("Exercise");
              myFrame.setSize(300,500);
              JLabel label1 = new JLabel("Name:");
              JLabel label2 = new JLabel("Password: ");
              JLabel label3 = new JLabel("Message: ");
              ButtonGroup buttongr = new ButtonGroup();
              JRadioButton button1 = new JRadioButton("Public Computer");
              JRadioButton button2 = new JRadioButton("Private Computer");
              buttongr.add(button1);
              buttongr.add(button2);
              JButton button3 = new JButton("Ok");
              JButton button4 = new JButton("Cancel");
               button3.addActionListener(new AddButtonListener (number1, number2, total));
              ButtonGroup buttongr2 = new ButtonGroup();
              buttongr2.add(button4);
              buttongr2.add(button3);

              //button3.addActionListener(this);

                    button3.addActionListener(new ActionListener ())

                    {



                    }


              JPanel panel1 = new JPanel();
              JPanel panel2 = new JPanel();
              myFrame.add(panel1, BorderLayout.CENTER);
              myFrame.add(panel2, BorderLayout.SOUTH);

              panel1.setLayout(new GridLayout (4,2));
              panel2.setLayout(new FlowLayout());
              JTextArea area1 = new JTextArea("Hello World, \nThis is my first proper GUI. I've done it! \nSteffen");
              JTextField text1 = new JTextField("Steffen");

              JPasswordField pass1 = new JPasswordField(15);
              panel1.add(label1);
              panel1.add(text1);
              panel1.add(label2);
              panel1.add(pass1);
              panel1.add(button1);
              panel1.add(button2);
              panel1.add(label3);
              panel1.add(area1);
              panel2.add(button3);
              panel2.add(button4);


              myFrame.pack();

              myFrame.setVisible(true);
          }
     public static void AdderApp
    {
     inner i;
        i = new ActionListener();

    }
                                                                 //if (e.getSource()==adder)      3
}

