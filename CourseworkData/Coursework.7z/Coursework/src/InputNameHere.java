/**
 * Created with IntelliJ IDEA.
 * User: Nocturnal Cyan
 * Date: 29/01/13
 * Time: 13:33
 * To change this template use File | Settings | File Templates.
 */
public class InputNameHere
{

}
