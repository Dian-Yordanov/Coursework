/**
 * Created with IntelliJ IDEA.
 * User: Nocturnal Cyan
 * Date: 29/01/13
 * Time: 13:34
 * To change this template use File | Settings | File Templates.
 */
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class AddButtonListener implements ActionListener
{
    JTextField jtfNumber1, jtfNumber2;
    JLabel jOutput;

    public AddButtonListener(JTextField jtfNumber1,JTextField jtfNumber2, JLabel jOutput)
    {
        super();
        this.jtfNumber1=jtfNumber1;
        this.jtfNumber2=jtfNumber2;
        this.jOutput=jOutput;
    }
 public void actionPerformed(ActionEvent e)
 {
    String number1, number2;
    number1=jtfNumber1.getText();
    number2=jtfNumber2.getText();
    float flResult=Float.parseFloat(number1)+Float.parseFloat(number2);
    jOutput.setText("" + flResult);














 }












}
